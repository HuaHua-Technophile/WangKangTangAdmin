import{_ as e}from"./_plugin-vue_export-helper-DlAUqK2U.js";const r={};function c(n,t){return"1"}const o=e(r,[["render",c]]);export{o as default};
