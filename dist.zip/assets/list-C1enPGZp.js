import{_ as r}from"./_plugin-vue_export-helper-DlAUqK2U.js";const t={};function c(e,_){return"1"}const s=r(t,[["render",c]]);export{s as default};
