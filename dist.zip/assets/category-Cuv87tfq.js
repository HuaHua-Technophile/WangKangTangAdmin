import{_ as r}from"./_plugin-vue_export-helper-DlAUqK2U.js";const c={};function e(t,_){return"1"}const o=r(c,[["render",e]]);export{o as default};
