import{_ as e}from"./_plugin-vue_export-helper-DlAUqK2U.js";const r={};function t(c,n){return"post"}const o=e(r,[["render",t]]);export{o as default};
