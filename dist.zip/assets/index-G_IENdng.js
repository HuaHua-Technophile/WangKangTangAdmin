import{_ as e}from"./_plugin-vue_export-helper-DlAUqK2U.js";const c={};function n(r,t){return"notice"}const o=e(c,[["render",n]]);export{o as default};
