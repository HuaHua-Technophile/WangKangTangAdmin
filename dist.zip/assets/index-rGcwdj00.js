import{_ as c}from"./_plugin-vue_export-helper-DlAUqK2U.js";const e={};function r(t,n){return"dict"}const o=c(e,[["render",r]]);export{o as default};
