import{_ as c}from"./_plugin-vue_export-helper-DlAUqK2U.js";const e={};function n(r,t){return"config"}const o=c(e,[["render",n]]);export{o as default};
